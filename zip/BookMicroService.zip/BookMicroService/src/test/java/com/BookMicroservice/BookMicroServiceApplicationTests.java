package com.BookMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
