package com.BookMicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMicroServiceApplication.class, args);
	}

}
