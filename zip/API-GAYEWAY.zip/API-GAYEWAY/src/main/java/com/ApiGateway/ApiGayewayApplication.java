package com.ApiGateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGayewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGayewayApplication.class, args);
	}

}
